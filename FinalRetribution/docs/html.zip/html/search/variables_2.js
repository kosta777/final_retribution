var searchData=
[
  ['difficulty',['difficulty',['../structgameStruct.html#a92d90890c541e904df08f468045e54eb',1,'gameStruct::difficulty()'],['../menu_8h.html#a016a5d341f375d13639c75bf5987fb23',1,'difficulty():&#160;menu.h']]]
];
