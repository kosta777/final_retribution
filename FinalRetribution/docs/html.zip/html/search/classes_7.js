var searchData=
[
  ['textstruct',['textStruct',['../structtextStruct.html',1,'']]]
];
