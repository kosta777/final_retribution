var searchData=
[
  ['hsfilememberstruct',['HSFileMemberStruct',['../structHSFileMemberStruct.html',1,'']]]
];
