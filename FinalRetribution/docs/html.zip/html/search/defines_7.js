var searchData=
[
  ['text_5ftexture_5fnum',['TEXT_TEXTURE_NUM',['../menu_8h.html#a1679fd7e79ac92280ed041e7beae947d',1,'menu.h']]],
  ['texts_5fnum',['TEXTS_NUM',['../game_8h.html#a6182b9182c2446eeda7a80e61e9304be',1,'game.h']]],
  ['top_5fstrip',['TOP_STRIP',['../defines_8h.html#a9ad69cf9087066033f76e1f466a5cba9',1,'defines.h']]]
];
