var searchData=
[
  ['path_5fid',['path_id',['../structenemyStruct.html#a0f91e2ddb629cc9a63b16e0a58b31619',1,'enemyStruct']]],
  ['pausesurface',['pauseSurface',['../structgameStruct.html#ab83d07cf79aef2a770f9f590ecc27892',1,'gameStruct']]],
  ['pausetexture',['pauseTexture',['../structgameStruct.html#ad5a51bda93418db95e0079ec48454d7b',1,'gameStruct']]],
  ['player',['player',['../structplayerListNodeStruct.html#aa17246cc44a7c136d887c4320a8de6bc',1,'playerListNodeStruct']]],
  ['players',['players',['../structgameStruct.html#ac7150f28033e8b75bbc1b23f54eda8bf',1,'gameStruct::players()'],['../game_8h.html#a76fe6a184bbb6e853b9166c59138dd88',1,'players():&#160;game.h']]],
  ['playerscount',['playersCount',['../structgameStruct.html#a46b5fa4b7d80669b25b5ae16cbf12e9d',1,'gameStruct']]],
  ['playertexture',['playerTexture',['../structgameStruct.html#a945e2e641e009434b80ca92f48e13b31',1,'gameStruct']]],
  ['playertextureleft',['playerTextureLeft',['../structgameStruct.html#a9a722d282a96b5198c17b655a698201a',1,'gameStruct']]],
  ['playertextureright',['playerTextureRight',['../structgameStruct.html#ab1efab47f33adc05860289a37d60ae5b',1,'gameStruct']]],
  ['position',['position',['../structplayerStruct.html#a292cd005e6284cb1ae2da17df2b7bc6a',1,'playerStruct::position()'],['../structenemyStruct.html#a4fdb07934f768c189553b0a954aaeeb8',1,'enemyStruct::position()'],['../structbulletStruct.html#a92ce24db5657ff208c9e8416335d6444',1,'bulletStruct::position()'],['../structeffectStruct.html#a8b75084599bc4d0be00157e387558660',1,'effectStruct::position()'],['../structpowerUpStruct.html#aeeba5b89a4575722cc3f1709a6896766',1,'powerUpStruct::position()']]],
  ['powerup',['powerUp',['../structpowerUpListNodeStruct.html#a25e81ba46e0573e2e77a167c94a0ad6f',1,'powerUpListNodeStruct']]],
  ['powerupnum',['powerUpNum',['../structsaveHeaderStruct.html#aca25685e0f0591f330e44edf6958352c',1,'saveHeaderStruct']]],
  ['powerups',['powerUps',['../structgameStruct.html#a2b30f66c44b1df5bc621feac0105a715',1,'gameStruct']]],
  ['poweruptexture',['powerUpTexture',['../structgameStruct.html#ae4790e605b0320c4818e783369c9975e',1,'gameStruct']]],
  ['prev',['prev',['../structplayerListNodeStruct.html#a173502a465293664699f31d1de7e8db6',1,'playerListNodeStruct::prev()'],['../structenemyListNodeStruct.html#afc4f8174dc235601179c1cfd15dce8c8',1,'enemyListNodeStruct::prev()'],['../structbulletListNodeStruct.html#af9bfc01774e0d6f02c0a9cc45ea257d3',1,'bulletListNodeStruct::prev()'],['../structeffectListNodeStruct.html#a91aeba94dc3750db9b3147059fc19f25',1,'effectListNodeStruct::prev()'],['../structpowerUpListNodeStruct.html#ac9806698e2df9f0fe650dc04f1ce686d',1,'powerUpListNodeStruct::prev()']]]
];
