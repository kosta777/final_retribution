var searchData=
[
  ['loadgame',['loadGame',['../savingGame_8c.html#a444424bf89afb7a2d2341b73cf7313fc',1,'loadGame(char *gamePath):&#160;savingGame.c'],['../savingGame_8h.html#acef41fee80103ba67f85c12a501d31bd',1,'loadGame(char *):&#160;savingGame.c']]]
];
