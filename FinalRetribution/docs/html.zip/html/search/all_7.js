var searchData=
[
  ['handleiteration',['handleIteration',['../structplayerStruct.html#a88ffc9c6b3d95e56d12d7fb0dd2fa105',1,'playerStruct::handleIteration()'],['../structenemyStruct.html#a04a2c7547562cba2fca3f669cd1c2012',1,'enemyStruct::handleIteration()'],['../structbulletStruct.html#af5ac113f73efb6e4d409a041c63e6341',1,'bulletStruct::handleIteration()'],['../structeffectStruct.html#a4c0be4c0678753a1deaf4ca7754df21b',1,'effectStruct::handleIteration()'],['../structpowerUpStruct.html#aa195e65475e4a5630c7a357b01a4b8c3',1,'powerUpStruct::handleIteration()'],['../structgameStruct.html#a66bd3216b8a146485172fd5014637d31',1,'gameStruct::handleIteration()']]],
  ['handlers_2eh',['handlers.h',['../handlers_8h.html',1,'']]],
  ['health',['health',['../structplayerStruct.html#a812bc32d8f9078364edc7d32c24ac616',1,'playerStruct::health()'],['../structenemyStruct.html#a618c1567fda32b619e77e8fe34ce92a6',1,'enemyStruct::health()']]],
  ['helprect',['helpRect',['../menu_8h.html#a5b7b3474a78ad20777c3755f7e6781d8',1,'menu.h']]],
  ['helptexture',['helpTexture',['../menu_8h.html#a3bae841209bdfdea4c2efc3b84ed8d02',1,'menu.h']]],
  ['helptiprect',['helpTipRect',['../menu_8h.html#a09f0c60d05592e5796a362bd018fbd92',1,'menu.h']]],
  ['holetexture',['holeTexture',['../structgameStruct.html#a26cac4a83bbf7ca604e12bf947c3a8c1',1,'gameStruct']]],
  ['hsbackgroundrect',['HSBackgroundRect',['../game_8h.html#a0a56fbb16d888562dee1a740dc46ec7e',1,'HSBackgroundRect():&#160;game.h'],['../handlers_8h.html#a0a56fbb16d888562dee1a740dc46ec7e',1,'HSBackgroundRect():&#160;game.h']]],
  ['hsbackgroundtexture',['HSBackgroundTexture',['../game_8h.html#af37bdf8f0eb4e00470caf1b7ae6675aa',1,'game.h']]],
  ['hsfilememberptr',['HSFileMemberPtr',['../game_8h.html#af827bf26186b10616516ecf37b5d6e1a',1,'game.h']]],
  ['hsfilememberstruct',['HSFileMemberStruct',['../structHSFileMemberStruct.html',1,'']]],
  ['hsfilename',['HSFileName',['../structgameStruct.html#a90a2df2e888fddcf9831bdb656ee49ba',1,'gameStruct']]],
  ['hsnames',['HSNames',['../structgameStruct.html#a37a739e4b26b2fc9d6f11afad13940ee',1,'gameStruct']]],
  ['hsscores',['HSScores',['../structgameStruct.html#a3bfbd13908a30d3eed25046edb2f181d',1,'gameStruct']]]
];
