var indexSectionsWithContent =
{
  0: "abcdefghiklmnprstuwxy",
  1: "beghmpst",
  2: "cdghims",
  3: "bdefgiklmprsu",
  4: "bcdefghilmnprstwxy",
  5: "beghmpst",
  6: "abefgmptw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Sve",
  1: "Strukture i unije",
  2: "Datoteke",
  3: "Funkcije",
  4: "Promenljive",
  5: "Definicije tipa",
  6: "Makro zamene"
};

