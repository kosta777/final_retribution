var searchData=
[
  ['textptr',['textPtr',['../defines_8h.html#a293352ea0d644d2f1aaf0366bb61f2ed',1,'defines.h']]]
];
