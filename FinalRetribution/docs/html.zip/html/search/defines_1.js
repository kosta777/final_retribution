var searchData=
[
  ['background_5fgrid_5fx',['BACKGROUND_GRID_X',['../defines_8h.html#a6a14c3d33b1ddaf19c291471315c90da',1,'defines.h']]],
  ['background_5fgrid_5fy',['BACKGROUND_GRID_Y',['../defines_8h.html#a74a1ea44fabf05b6ef7702a02f869b2d',1,'defines.h']]],
  ['background_5fspeed',['BACKGROUND_SPEED',['../defines_8h.html#a559eee5607728a57c19c8fba5323eb37',1,'defines.h']]],
  ['background_5ftile_5fsize',['BACKGROUND_TILE_SIZE',['../defines_8h.html#ab3d2dfc21d4415293593b0ca021e3130',1,'defines.h']]],
  ['backgrounds_5fnum',['BACKGROUNDS_NUM',['../defines_8h.html#a0f18100ff2e56bfdcb89d01f79e14814',1,'defines.h']]],
  ['bottom_5fstrip',['BOTTOM_STRIP',['../defines_8h.html#abd240a1260de97094d1fae44fe935bd7',1,'defines.h']]]
];
