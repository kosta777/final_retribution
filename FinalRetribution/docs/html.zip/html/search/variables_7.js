var searchData=
[
  ['id',['id',['../structenemyStruct.html#a38311943a164340e750edc4b030c5fa2',1,'enemyStruct::id()'],['../structbulletStruct.html#abed6d71bbaa7de03adc528fb9d7fc3d1',1,'bulletStruct::id()'],['../structeffectStruct.html#a7d4f6db711c5c8b9ecbde2f21fdce99f',1,'effectStruct::id()'],['../structpowerUpStruct.html#a4e94682792e139a35424fa956c12b159',1,'powerUpStruct::id()']]],
  ['isplayerowned',['isPlayerOwned',['../structbulletStruct.html#a84c03c9cbe186da85ed92d57c353ded6',1,'bulletStruct']]]
];
