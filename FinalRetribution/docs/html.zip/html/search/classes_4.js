var searchData=
[
  ['maxlevelsavestruct',['maxLevelSaveStruct',['../structmaxLevelSaveStruct.html',1,'']]]
];
