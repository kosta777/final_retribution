var searchData=
[
  ['gameptr',['gamePtr',['../defines_8h.html#a6f38fc2fb6ebaba8392c72e019b4fb22',1,'defines.h']]]
];
