var searchData=
[
  ['playerlistnodeptr',['playerListNodePtr',['../defines_8h.html#a28bd87f0ea5f472c923866adb33d7e99',1,'defines.h']]],
  ['playerptr',['playerPtr',['../defines_8h.html#a3647424a8a7566b6538099a8a8d14e7f',1,'defines.h']]],
  ['poweruplistnodeptr',['powerUpListNodePtr',['../defines_8h.html#a4f26730e983e328253a2671686fe929e',1,'defines.h']]],
  ['powerupptr',['powerUpPtr',['../defines_8h.html#aa043fa500285a0061cd98b4d4d865cbd',1,'defines.h']]]
];
