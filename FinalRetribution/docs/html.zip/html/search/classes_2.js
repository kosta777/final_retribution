var searchData=
[
  ['gamestruct',['gameStruct',['../structgameStruct.html',1,'']]]
];
