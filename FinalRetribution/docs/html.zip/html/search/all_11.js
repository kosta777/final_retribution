var searchData=
[
  ['updateeffects',['updateEffects',['../game_8c.html#ae66a41d2704031377ade5a7da460cc3f',1,'game.c']]]
];
