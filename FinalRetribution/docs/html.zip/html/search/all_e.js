var searchData=
[
  ['rect',['rect',['../structtextStruct.html#aaf262cd94bf0cf270d36b05b2e4b31fc',1,'textStruct']]],
  ['renderer',['renderer',['../draw_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../collisions_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../game_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../handlers_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../savingGame_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../instances_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../main_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h'],['../menu_8h.html#a966da7a60c4ea3ba301e26ccc5efe452',1,'renderer():&#160;main.h']]],
  ['rendergame',['renderGame',['../game_8c.html#ad502ac625f17fb361a2aae197a161246',1,'renderGame():&#160;game.c'],['../game_8h.html#a79eb7111efe9c8656a000fbeab8cb23e',1,'renderGame(void):&#160;game.c']]],
  ['rungame',['runGame',['../game_8c.html#aa3a42b6202b319d9d236a4519d088e62',1,'runGame():&#160;game.c'],['../game_8h.html#a7acbcc06f234627232401c1a1568d61f',1,'runGame(void):&#160;game.c']]]
];
