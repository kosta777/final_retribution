var searchData=
[
  ['game_5fname',['GAME_NAME',['../defines_8h.html#aed7818555b2da57314243d796315e4e9',1,'defines.h']]]
];
