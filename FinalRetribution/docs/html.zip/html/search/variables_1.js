var searchData=
[
  ['campaign_5fbackground',['campaign_background',['../campaign_8c.html#aa7aa4638409f5c664f9180181216422d',1,'campaign_background():&#160;campaign.c'],['../campaign_8h.html#a9d817a27f96d46ca88cae92790e559ea',1,'campaign_background():&#160;campaign.h']]],
  ['campaign_5flevel_5find',['campaign_level_ind',['../structgameStruct.html#a57df1d942606cc50309adb27b7219a04',1,'gameStruct']]],
  ['campaign_5frow',['campaign_row',['../structgameStruct.html#a8c6e454d3d3f408ec9b2e6f97263896c',1,'gameStruct']]],
  ['color',['color',['../structtextStruct.html#aef36bae01138a011ac4f0a19d08bc8ac',1,'textStruct']]],
  ['cooldown',['coolDown',['../structenemyStruct.html#a815f197b0413cd63142dd77a836b509d',1,'enemyStruct']]],
  ['counter',['counter',['../structplayerStruct.html#aff1fa1f8144ac4eedb8347caabc1f7de',1,'playerStruct::counter()'],['../structenemyStruct.html#ac6f09012496b2e3fd59e12d997d8f3be',1,'enemyStruct::counter()'],['../structbulletStruct.html#a7ae9736e0bf89f85e409964c63300927',1,'bulletStruct::counter()'],['../structeffectStruct.html#a9c5d5ae671079ca6080e3404d47bd6b7',1,'effectStruct::counter()'],['../structpowerUpStruct.html#a5ade1ecba268c2b26c316b89c6596870',1,'powerUpStruct::counter()']]]
];
