var searchData=
[
  ['players_5fnum',['PLAYERS_NUM',['../game_8h.html#ad69123c34bb31d143a1229585c09aae9',1,'game.h']]]
];
