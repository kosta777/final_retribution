var searchData=
[
  ['y_5fpos',['y_pos',['../structplayerStruct.html#aa45ebd9afbf89967817446e516ee61f6',1,'playerStruct::y_pos()'],['../structenemyStruct.html#ae3356408ee74bd6ea61b1e4bc3110d04',1,'enemyStruct::y_pos()'],['../structbulletStruct.html#a743ad1d8355d8c159625b2a3ec340ae1',1,'bulletStruct::y_pos()'],['../structeffectStruct.html#ab0efb02236d1857fe597dc4c7dd1bd6c',1,'effectStruct::y_pos()'],['../structpowerUpStruct.html#a19de35a855d167343e70ba684f558cf0',1,'powerUpStruct::y_pos()']]]
];
