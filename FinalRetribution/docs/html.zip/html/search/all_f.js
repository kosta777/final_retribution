var searchData=
[
  ['savegame',['saveGame',['../savingGame_8c.html#a77f24aa4e1e113dcd298ec6106f59b27',1,'saveGame(char *gamePath):&#160;savingGame.c'],['../savingGame_8h.html#a65399d384d3b2bebc9257bb3ab9a9fcd',1,'saveGame(char *):&#160;savingGame.c']]],
  ['saveheaderptr',['saveHeaderPtr',['../savingGame_8h.html#a435103c4ec26ea4d436b7dfe76d468dc',1,'savingGame.h']]],
  ['saveheaderstruct',['saveHeaderStruct',['../structsaveHeaderStruct.html',1,'']]],
  ['savehighscore',['saveHighScore',['../constructors_8c.html#a854f8b7233106cac5edac6a698b728a0',1,'saveHighScore():&#160;constructors.c'],['../instances_8h.html#a854f8b7233106cac5edac6a698b728a0',1,'saveHighScore():&#160;constructors.c']]],
  ['savinggame_2ec',['savingGame.c',['../savingGame_8c.html',1,'']]],
  ['savinggame_2eh',['savingGame.h',['../savingGame_8h.html',1,'']]],
  ['score',['score',['../structenemyStruct.html#a73c61c7ce20e077505d66cf5f6257de8',1,'enemyStruct::score()'],['../structgameStruct.html#a510df9a3df130b0cc8ecc8c8827e23b3',1,'gameStruct::score()'],['../structHSFileMemberStruct.html#a3d2396a55416114b902a7e2dbcd2fb76',1,'HSFileMemberStruct::score()']]],
  ['selectcampaignlevel',['selectCampaignLevel',['../menu_8c.html#a7f8f1f317aefb0e9a8686f14343f72e0',1,'menu.c']]],
  ['selector2pos',['selector2Pos',['../menu_8h.html#a8ce9ce644fc2088bc759351028761ab1',1,'menu.h']]],
  ['selector2rect',['selector2Rect',['../menu_8h.html#a9b6902c0f615f2bdccee10ac720332f5',1,'menu.h']]],
  ['selectorpos',['selectorPos',['../menu_8h.html#a044f583c3cce869526a998e9538ac7ec',1,'menu.h']]],
  ['selectorrect',['selectorRect',['../menu_8h.html#a382fcd92f3bce4870923b41c91b192a9',1,'menu.h']]],
  ['selectortexture',['selectorTexture',['../menu_8h.html#aff0637e1242a02431e3e290b7eb10d78',1,'menu.h']]],
  ['shieldactive',['shieldActive',['../structplayerStruct.html#ae00a110c56f8e07e53afac3171ba916f',1,'playerStruct']]],
  ['shieldtexture',['shieldTexture',['../structgameStruct.html#a2be3629363472306953b89e92e04ceac',1,'gameStruct']]],
  ['show',['show',['../structtextStruct.html#a26affb29e94062417d65e30567023e7d',1,'textStruct']]],
  ['showmenu',['showMenu',['../menu_8c.html#a0be44243f30672c846deedaf6b3660f9',1,'showMenu():&#160;menu.c'],['../menu_8h.html#a0be44243f30672c846deedaf6b3660f9',1,'showMenu():&#160;menu.c']]],
  ['speedactive',['speedActive',['../structplayerStruct.html#a9850ed9628bcafc3cae5a5143c735b73',1,'playerStruct']]],
  ['speedtexture',['speedTexture',['../structgameStruct.html#a27121b109498d5a1fc5a386fe0b4181f',1,'gameStruct']]],
  ['str',['str',['../structtextStruct.html#a0105fb9f5b6564bda290bb6e39c004da',1,'textStruct']]],
  ['swap_5ftile_5frows',['swap_tile_rows',['../game_8c.html#af8985da10d99eb8163aef166068d15d8',1,'game.c']]]
];
