var searchData=
[
  ['hsfilememberptr',['HSFileMemberPtr',['../game_8h.html#af827bf26186b10616516ecf37b5d6e1a',1,'game.h']]]
];
