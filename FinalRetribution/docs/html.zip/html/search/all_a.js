var searchData=
[
  ['lastcampaignlevel',['lastCampaignLevel',['../draw_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../collisions_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../game_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../handlers_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../savingGame_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../instances_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../main_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h'],['../menu_8h.html#aa24fa980418f6787bc9a187c00487a10',1,'lastCampaignLevel():&#160;main.h']]],
  ['level',['level',['../structmaxLevelSaveStruct.html#aa697f0d5c570e354e501911d19bc1fda',1,'maxLevelSaveStruct']]],
  ['level_5fdefault',['level_default',['../structgameStruct.html#ab5f65877bbfa67b83f26d4803b5392c4',1,'gameStruct']]],
  ['level_5ffile',['level_file',['../structgameStruct.html#aac7291016ed52ae794d099e0ce47c9a7',1,'gameStruct']]],
  ['level_5fmatrix',['level_matrix',['../structgameStruct.html#acf1d00b4536d8a503cce96bde1089c2a',1,'gameStruct']]],
  ['levelcleartexture',['levelClearTexture',['../game_8h.html#afea178bddc17e50ea32202a6f2451d16',1,'game.h']]],
  ['loadgame',['loadGame',['../savingGame_8c.html#a444424bf89afb7a2d2341b73cf7313fc',1,'loadGame(char *gamePath):&#160;savingGame.c'],['../savingGame_8h.html#acef41fee80103ba67f85c12a501d31bd',1,'loadGame(char *):&#160;savingGame.c']]],
  ['logorect',['logoRect',['../menu_8h.html#af68b07938b3fb0d0af60250009f3206f',1,'menu.h']]],
  ['logotexture',['logoTexture',['../menu_8h.html#a52ff08ea6f6a35dc88027124ff1f03c6',1,'menu.h']]]
];
