var searchData=
[
  ['initbullet',['initBullet',['../constructors_8c.html#af7fc704b833c332e2d36ec0bbae4aa17',1,'initBullet(double x, double y, short isPlayerOwned, int type):&#160;constructors.c'],['../instances_8h.html#a80858376a23d98756178e4a3a1a15468',1,'initBullet(double, double, short, int):&#160;constructors.c']]],
  ['initeffect',['initEffect',['../constructors_8c.html#a15c0b0d804d0b393b3d9d5f35d9e6041',1,'initEffect(double x, double y, int type):&#160;constructors.c'],['../instances_8h.html#ad6f4e639d5da6845332aaafc16809b05',1,'initEffect(double, double, int):&#160;constructors.c']]],
  ['initenemy',['initEnemy',['../constructors_8c.html#ae5f9127b8f25cf9db05621df903d9f00',1,'initEnemy(double x_pos, double y_pos, int id, int path_id):&#160;constructors.c'],['../instances_8h.html#ac962fd8c39b53a007c64750277ce1f57',1,'initEnemy(double, double, int, int):&#160;constructors.c']]],
  ['initgame',['initGame',['../constructors_8c.html#ae010d34b01c4e66eb2c36b80c647da65',1,'initGame(int game_mode, char *s, int difficulty):&#160;constructors.c'],['../instances_8h.html#ab35e0e89fe4c024ac19f547caeeb24ac',1,'initGame(int, char *, int):&#160;constructors.c']]],
  ['initlevelmatrix',['initLevelMatrix',['../constructors_8c.html#a2fc3f07d245d826e7f572a2759520304',1,'initLevelMatrix():&#160;constructors.c'],['../instances_8h.html#a2fc3f07d245d826e7f572a2759520304',1,'initLevelMatrix():&#160;constructors.c']]],
  ['initload_5fcurr_5flvl',['initLoad_curr_lvl',['../instances_8h.html#ae810d71592d510698be6f2ab08034e7a',1,'instances.h']]],
  ['initplayer',['initPlayer',['../constructors_8c.html#a1dca549e20947032febfdf3cda5dbd8b',1,'initPlayer():&#160;constructors.c'],['../instances_8h.html#a1dca549e20947032febfdf3cda5dbd8b',1,'initPlayer():&#160;constructors.c']]],
  ['initpowerup',['initPowerUp',['../constructors_8c.html#a814f3d0a607054ece6238df6ff3ad807',1,'initPowerUp(double x, double y, int type):&#160;constructors.c'],['../instances_8h.html#ad4953c19c5cf93a9c42260e4be77fa37',1,'initPowerUp(double, double, int):&#160;constructors.c']]],
  ['initprogram',['initProgram',['../main_8c.html#ab1df961eef8a495e546c750e0eb31857',1,'main.c']]],
  ['inittext',['initText',['../constructors_8c.html#ab3887de3e5ac6bac97a06f2f67e13e32',1,'initText(textPtr *textTexture, int x, int y, int col1, int col2, int col3, int col4, TTF_Font *font, char *str):&#160;constructors.c'],['../instances_8h.html#a8b226d1a90ea0105b6a29840a719039a',1,'initText(textPtr *, int, int, int, int, int, int, TTF_Font *, char *):&#160;constructors.c']]],
  ['inittextures',['initTextures',['../constructors_8c.html#a3d68d735fc512acefb923aa328678e60',1,'initTextures():&#160;constructors.c'],['../instances_8h.html#a3d68d735fc512acefb923aa328678e60',1,'initTextures():&#160;constructors.c']]]
];
