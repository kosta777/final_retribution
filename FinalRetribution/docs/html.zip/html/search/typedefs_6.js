var searchData=
[
  ['saveheaderptr',['saveHeaderPtr',['../savingGame_8h.html#a435103c4ec26ea4d436b7dfe76d468dc',1,'savingGame.h']]]
];
