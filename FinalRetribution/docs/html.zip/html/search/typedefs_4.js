var searchData=
[
  ['maxlevelsaveptr',['maxLevelSavePtr',['../game_8h.html#a747919017f4778ec416a703c27ed703f',1,'game.h']]]
];
