var searchData=
[
  ['effectlistnodeptr',['effectListNodePtr',['../defines_8h.html#ac18a3f2369a7ca29ad4c5b5d19c7ca7c',1,'defines.h']]],
  ['effectptr',['effectPtr',['../defines_8h.html#a99676bdc11924cf644bd2f9a65505529',1,'defines.h']]],
  ['enemylistnodeptr',['enemyListNodePtr',['../defines_8h.html#a8f6ca0a49f92df8ac9ea4e3b729b286b',1,'defines.h']]],
  ['enemyptr',['enemyPtr',['../defines_8h.html#a753773edee8f32862d3dbf418cd3cf44',1,'defines.h']]]
];
