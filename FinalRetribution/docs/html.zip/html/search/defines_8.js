var searchData=
[
  ['windowh',['WINDOWH',['../defines_8h.html#af9a655e097f60f1937aca240eeac8c6d',1,'defines.h']]],
  ['windoww',['WINDOWW',['../defines_8h.html#a6315de7001c24450d733a4832012388e',1,'defines.h']]]
];
