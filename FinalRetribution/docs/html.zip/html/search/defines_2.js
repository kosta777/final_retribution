var searchData=
[
  ['enemy_5fnum',['ENEMY_NUM',['../defines_8h.html#a273f4312dff9af21642b8ca2629380a5',1,'defines.h']]],
  ['enemy_5fplane_5ftypes',['ENEMY_PLANE_TYPES',['../defines_8h.html#a932665efca44d526b119f71d8db185bf',1,'defines.h']]]
];
