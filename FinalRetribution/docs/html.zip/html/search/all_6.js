var searchData=
[
  ['game',['game',['../draw_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../collisions_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../game_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../handlers_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../savingGame_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../instances_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../main_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h'],['../menu_8h.html#a3a75c61e7825dda20578b000d3bbb712',1,'game():&#160;main.h']]],
  ['game_2ec',['game.c',['../game_8c.html',1,'']]],
  ['game_2eh',['game.h',['../game_8h.html',1,'']]],
  ['game_5fmode',['game_mode',['../structgameStruct.html#afc97c4ad9f18fad3b8e11b2fadd90526',1,'gameStruct']]],
  ['game_5fname',['GAME_NAME',['../defines_8h.html#aed7818555b2da57314243d796315e4e9',1,'defines.h']]],
  ['gameitrationhandlerdefault',['gameItrationHandlerDefault',['../handlers_8h.html#ad35c42f43a96b176c2a1f1da690dddeb',1,'gameItrationHandlerDefault():&#160;iterationHandlers.c'],['../iterationHandlers_8c.html#ad35c42f43a96b176c2a1f1da690dddeb',1,'gameItrationHandlerDefault():&#160;iterationHandlers.c']]],
  ['gameoverrect',['gameOverRect',['../game_8h.html#aa7860a5a1c234183407c98e1807331b8',1,'gameOverRect():&#160;game.h'],['../handlers_8h.html#aa7860a5a1c234183407c98e1807331b8',1,'gameOverRect():&#160;game.h']]],
  ['gameovertexture',['gameOverTexture',['../game_8h.html#aa2eff98a400ac8e92b53729f3264b92d',1,'game.h']]],
  ['gameptr',['gamePtr',['../defines_8h.html#a6f38fc2fb6ebaba8392c72e019b4fb22',1,'defines.h']]],
  ['gamestruct',['gameStruct',['../structgameStruct.html',1,'']]],
  ['getlevelfilename',['getLevelFileName',['../menu_8c.html#a2680b394faac65692d8f1ed2e52d3876',1,'menu.c']]],
  ['getsavedgamename',['getSavedGameName',['../menu_8c.html#ac3dc48f6c614df528d34f4f7d9ac674e',1,'menu.c']]]
];
