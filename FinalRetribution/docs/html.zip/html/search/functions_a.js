var searchData=
[
  ['rendergame',['renderGame',['../game_8c.html#ad502ac625f17fb361a2aae197a161246',1,'renderGame():&#160;game.c'],['../game_8h.html#a79eb7111efe9c8656a000fbeab8cb23e',1,'renderGame(void):&#160;game.c']]],
  ['rungame',['runGame',['../game_8c.html#aa3a42b6202b319d9d236a4519d088e62',1,'runGame():&#160;game.c'],['../game_8h.html#a7acbcc06f234627232401c1a1568d61f',1,'runGame(void):&#160;game.c']]]
];
