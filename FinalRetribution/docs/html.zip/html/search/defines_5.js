var searchData=
[
  ['max',['MAX',['../defines_8h.html#aff9931d7524c88e07743af6535b20761',1,'defines.h']]],
  ['min',['MIN',['../defines_8h.html#ad2f3678bf5eae3684fc497130b946eae',1,'MIN():&#160;defines.h'],['../collisions_8c.html#ad2f3678bf5eae3684fc497130b946eae',1,'MIN():&#160;collisions.c']]]
];
