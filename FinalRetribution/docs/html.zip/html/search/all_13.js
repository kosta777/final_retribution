var searchData=
[
  ['x_5fpos',['x_pos',['../structplayerStruct.html#aa2208dfc7e02af471b0e2509774b46a4',1,'playerStruct::x_pos()'],['../structenemyStruct.html#aa007d4760d56ad4a89cffbac3127b617',1,'enemyStruct::x_pos()'],['../structbulletStruct.html#aa08cf0fb603badae86525633a8307b04',1,'bulletStruct::x_pos()'],['../structeffectStruct.html#a071722b30f32bb852fa609213b360e73',1,'effectStruct::x_pos()'],['../structpowerUpStruct.html#a09697e2f3cd76159ee86e4a10f71b54b',1,'powerUpStruct::x_pos()']]]
];
